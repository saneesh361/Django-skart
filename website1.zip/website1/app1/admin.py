from django.contrib import admin
from . models import Contact
from . models import Registration
from . models import Product
from . models import Cart
from . models import Order
from . models import Category
from . models import Wishlist
from . models import Notification,Notification1
from . models import Adminregistration

# Register your models here.

admin.site.register(Contact)
admin.site.register(Registration)
admin.site.register(Product)
admin.site.register(Cart)
admin.site.register(Order)
admin.site.register(Category)
admin.site.register(Wishlist)
admin.site.register(Notification)
admin.site.register(Adminregistration)
admin.site.register(Notification1)