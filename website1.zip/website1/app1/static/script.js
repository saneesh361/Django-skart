// document.getElementById("demo").style.textAlign="center";





