from django.urls import path
from . import views
from django.conf import settings
from django.conf.urls.static import static

urlpatterns = [
    path('',views.index,name='index'),
    path('about',views.about,name='about'),
    path('products',views.products,name='products'),
    path('addtowish/<int:id>',views.addtowish,name='addtowish'),
    path('addtocart/<int:id>',views.addtocart,name='addtocart'),
    path('wishlist',views.wishlist,name='wishlist'),
    path('cart',views.cart,name='cart'),
    path('services',views.services,name='services'),
    path('contact',views.contact,name='contact'),
    path('registration',views.registration,name='registration'),
    path('login',views.login,name='login'),
    path('account',views.account,name='account'),
    path('checkout',views.checkout,name='checkout'),
    path('confirmorder',views.confirmorder,name='confirmorder'),
    path('myorders',views.myorders,name='myorders'),
    path('logout',views.logout,name='logout'),
   
  
# admin
    path('addproducts',views.addproducts,name='addproducts'),
    path('addcategory',views.addcategory,name='addcategory'),
    path('viewproducts',views.viewproducts,name='viewproducts'),
    path('editproducts/<int:id>',views.editproducts,name='editproducts'),
    path('editcategory/<int:id>',views.editcategory,name='editcategory'),
    path('editnotification/<int:id>',views.editnotification,name='editnotification'),
    path('viewcategory',views.viewcategory,name='viewcategory'),
    path('addnotification',views.addnotification,name='addnotification'),
    path('viewnotification',views.viewnotification,name='viewnotification'),
    path('vieworders',views.vieworders,name='vieworders'),
    path('vieworders/<int:id>',views.vieworders1,name='vieworders'),
    path('adminlogin',views.adminlogin,name='adminlogin'),
    path('adminlogout',views.adminlogout,name='adminlogout'),


]

urlpatterns += static(settings.MEDIA_URL,document_root=settings.MEDIA_ROOT)